<?php

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Login</title>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="dist/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="dist/css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="dist/js/bootstrap.min.js"></script>
    </head>
    <body>
        <form role="form">
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd">
  </div>
  <div class="checkbox">
    <label><input type="checkbox"> Remember me</label>
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>
    </body>
</html>
