<?php

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Medicos</title>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="dist/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="dist/css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="dist/js/bootstrap.min.js"></script>
    </head>
    <body>
        <form role="form">
</form>
    </body>
</html>
