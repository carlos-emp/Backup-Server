<?php

    $palabras=split(� �,�hola como estas yo me llamo joel�);

   for($i=0;$palabras[$i];$i++)

    echo $palabras[$i],�<br>�;

//simplemente, este codigo me arrojar�a mediante el for cada palabra que es separada por un //espacio en blanco y mediante el Split este indentificador seria de tipo array

?>