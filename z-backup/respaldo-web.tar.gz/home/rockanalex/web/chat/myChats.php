<?php

//$me = $_GET["me"];


$servername = "localhost";
$username = "root";
$password = "19Alex90";
$dbname = "chat";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn -> connect_error) {
	die(json_encode(array("response" => "CONNECTION_ERROR", "detail" => $conn -> connect_error)));
}

$sql = "SELECT * from chat_privado WHERE chat_privado.from='$me' OR chat_privado.to='$me';";


	/* Consultas de selección que devuelven un conjunto de resultados */
if ($resultado = $conn->query($sql)) {
	$json = array();
   while($row = mysqli_fetch_array ($resultado))     
{
	/*
	 //***********************thum 1*********************************
	
		
	$campos1=explode('%META:FORM{name="%25SYSTEMWEB%25.UserForm"}%',file_get_contents("http://www.empowerlabs.com/intellibanks/data/Main/".$row['from'].".txt"));
    $n1=count($campos1);
	$campo1=explode('%META:FIELD{',$campos1[$n1-1]);
	$image1= explode('"',$campo1[14]);
	 //***********************thum 2*********************************
	
		
	$campos2=explode('%META:FORM{name="%25SYSTEMWEB%25.UserForm"}%',file_get_contents("http://www.empowerlabs.com/intellibanks/data/Main/".$row['to'].".txt"));
    $n2=count($campos2);
	$campo2=explode('%META:FIELD{',$campos2[$n2-1]);
	$image2= explode('"',$campo2[14]);
	
    $bus = array(
        'id' => $row['id'],
        'from' => $row['from'],
        'to' => $row['to'],
        'who' => $row['who'],
        "thum1"=>utf8_encode ("http://www.empowerlabs.com/intellibanks/pub/Main/".$row['from'] ."/".utf8_encode ($image1[7])),
        "thum2"=>utf8_encode ("http://www.empowerlabs.com/intellibanks/pub/Main/".$row['to']."/".utf8_encode ($image2[7]))
    );*/
    $bus = array(
        'id' => $row['id'],
        'from' => $row['from'],
        'to' => $row['to'],
        'who' => $row['who'],
        'seen' => $resultado->num_rows
		);
    array_push($json, $bus);
}

//echo json_encode(array("response"=>"OK","detail"=>$json));
    /* liberar el conjunto de resultados */
    $resultado->close();
	
}
else {
    echo json_encode(array("response"=>"ERROR","detail"=>$conn->error));
}

	
?>