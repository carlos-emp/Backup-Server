<?php
session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

		<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

		<!-- Compiled and minified CSS -->
		<link rel="stylesheet" href="css/materializaer.css">

		<!-- Compiled and minified JavaScript -->
		<script src="js/materializer.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.3.14/angular.min.js"></script>
		<script type="text/javascript" src="js/index.js"></script>

		<link rel="stylesheet" href="css/index.css" />
		<title>Inicio</title>
	</head>
	<body>
		<div class="navbar-fixed">
			<nav class="pink darken-2">
				<a href="#!" class="brand-logo"><img src="img/logos/logo-footer.png" style="max-height: 60px; max-width: auto" /></a>
				<ul class="right">
					<li>
						<a href='#'> <?php
						if (isset($_SESSION['nombre'])&&isset($_SESSION['nivel'])) {
							if($_SESSION['nivel']==='admin'){
								echo "" . $_SESSION['nombre'];
							}else{
								header("Location: login.php");
								die();
							}

						} else {
							header("Location: login.php");
							die();
							//echo "" . $_SESSION['nombre']. $_SESSION['nivel'];
						}
						?></a>
					</li>
					<li>
						<a href="inicio.php">Cotizador</a>
					</li>
					<li>
						<a href='logout.php'>Cerrar Sesion</a>
					</li>
				</ul>
			</nav>
		</div>
		<div class="container">
		</div>
	</body>
</html>
