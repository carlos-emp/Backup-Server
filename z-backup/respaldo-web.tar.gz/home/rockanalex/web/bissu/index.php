<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		
		<link rel="stylesheet" href="css/index.css" />
		
		<script src="lib/onsen/js/angular/angular.js"></script>
		<script type="text/javascript" src="js/index.js"></script>
		
		<title>Bissú Cotizador</title>
	</head>
	<body ng-controller="BodyController">
	</body>
</html>
