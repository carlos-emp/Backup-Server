

$(document).ready(function(){
$("#imprime").submit(function(){
	window.location="login.php";
});
$("#senseInput").on('input',function() {
  if($("#senseInput").val()===""){
  	$("#sense").fadeOut();
  	
	$("#agregar").addClass("disabled");
	$("#cantidadInput").val('');
  }
  else{
  	$("#sense").fadeIn();
  }
});
});
var selectedArticulo={};
var app= angular.module('Cotizador',[]);
app.controller('UsersController',function($scope,$http){
$scope.name='';
$scope.items={};
	$scope.iva=0;
	$scope.mihtml2='';
	$scope.counter=1;
	$scope.totalCol=0;
	$scope.totalfinol=0;
   $http.get('ws/products/getProductos.php').success(function(data){
$scope.items=data;
});
$scope.completar=function(item){
	selectedArticulo=item;
	$("#senseInput").val(item.nombre);
	$("#cantidadInput").val(item.en_existencia);
	$("#sense").fadeOut();
	$("#agregar").removeClass("disabled");
};
$scope.agregarFila=function(){
	$scope.actualPrecio=selectedArticulo.precio;
	if(parseInt($("#cantidadInput").val())>2){
		$scope.actualPrecio=selectedArticulo.mayoreo;
	}
	$scope.totalRow=parseFloat($("#cantidadInput").val())*parseFloat($scope.actualPrecio);
	$('#tabla').append("<tr class='row'><td class='col s1'>"+$scope.counter+
	"</td><td class='col s4'>"+selectedArticulo.nombre+
	"</td><td class='col s2'>"+$scope.actualPrecio+
	"</td><td class='col s3'>"+$("#cantidadInput").val()+
	"</td><td class='col s2'>"+$scope.totalRow+
	"</td></tr>");
	if(parseInt($scope.counter)>2){
		$scope.iva=16;
	}
	$scope.totalCol=parseFloat($scope.totalCol)+parseFloat($scope.totalRow);
	$scope.uno=parseFloat($scope.totalCol)/100.0;
	$scope.sub=parseFloat($scope.uno)*parseFloat($scope.iva);
	$scope.totalFinal=parseFloat($scope.totalCol)+parseFloat($scope.sub);
	$scope.mihtml2+="+"+$scope.counter+
	"-"+selectedArticulo.nombre+
	"-"+$scope.actualPrecio+
	"-"+$("#cantidadInput").val()+
	"-"+$scope.totalRow+
	"_";
	$('#mihtml').val($scope.mihtml2);
	$('#mtotales').val("+ Sub Total: "+$scope.totalCol+" - Sub Total: "+$scope.sub+" - Total: "+$scope.totalFinal+"_");
	
	$scope.counter++;
};
$scope.reset=function(){
	
$scope.name='';

	selectedArticulo={};
	$scope.iva=0;
	$scope.mihtml2='';
	$scope.counter=1;
	$scope.totalCol=0;
	$scope.totalfinol=0;
	$("#agregar").addClass("disabled");
	$('#tabla').html('');
};
});