<?php
header("Location:web/negocio/ads.html");
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Inicio</title>
        <style>
            body{
                background-color: #25313E;
                padding: 0px;
            }
            .publicidad{
                height: 85%;
                width: 96%;
                margin-left: 2%;
                position: absolute;
                background: #ff6a00;
            }
        </style>
    </head>
    <body>
        <div class="publicidad"></div>
    </body>
</html>
